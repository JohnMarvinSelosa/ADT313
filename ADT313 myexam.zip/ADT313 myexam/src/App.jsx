// src/App.js
import React, { useReducer, useState, useEffect, useCallback } from 'react';
import debounce from 'lodash.debounce';
import './App.css';

const initialState = {
  firstName: '',
  lastName: '',
  password: '',
  section: '',
  loggedIn: false,
  operation: '',
  number1: '',
  number2: '',
  result: null,
};

const reducer = (state, action) => {
  switch (action.type) {
    case 'LOGIN':
      return { ...state, loggedIn: true };
    case 'SET_FIRST_NAME':
      return { ...state, firstName: action.payload };
    case 'SET_LAST_NAME':
      return { ...state, lastName: action.payload };
    case 'SET_PASSWORD':
      return { ...state, password: action.payload };
    case 'SET_SECTION':
      return { ...state, section: action.payload };
    case 'SET_OPERATION':
      return { ...state, operation: action.payload };
    case 'SET_NUMBER1':
      return { ...state, number1: action.payload };
    case 'SET_NUMBER2':
      return { ...state, number2: action.payload };
    case 'SET_RESULT':
      return { ...state, result: action.payload };
    default:
      return state;
  }
};

const App = () => {
  const [state, dispatch] = useReducer(reducer, initialState);
  const [debouncedName, setDebouncedName] = useState(`${state.firstName} ${state.lastName}`);

  useEffect(() => {
    const handler = debounce(() => {
      setDebouncedName(`${state.firstName} ${state.lastName}`);
    }, 300);
    
    handler();

    return () => {
      handler.cancel();
    };
  }, [state.firstName, state.lastName]);

  const handleLogin = useCallback(() => {
    if (state.firstName && state.lastName && state.password) {
      dispatch({ type: 'LOGIN' });
    }
  }, [state.firstName, state.lastName, state.password]);

  const handleOperation = useCallback((op) => {
    dispatch({ type: 'SET_OPERATION', payload: op });
  }, []);

  const calculateResult = useCallback(() => {
    const num1 = parseFloat(state.number1);
    const num2 = parseFloat(state.number2);
    let result;

    switch (state.operation) {
      case '+':
        result = num1 + num2;
        break;
      case '-':
        result = num1 - num2;
        break;
      case '*':
        result = num1 * num2;
        break;
      case '/':
        result = num2 !== 0 ? num1 / num2 : 'Error';
        break;
      default:
        result = null;
    }

    dispatch({ type: 'SET_RESULT', payload: result });
  }, [state.number1, state.number2, state.operation]);

  return (
    <div className="container">
      {!state.loggedIn ? (
        <div>
          {/* Each input in its own row */}
          <div className="form-row">
            <input 
              type="text" 
              placeholder="First Name" 
              onChange={(e) => dispatch({ type: 'SET_FIRST_NAME', payload: e.target.value })} 
            />
          </div>
          <div className="form-row">
            <input 
              type="text" 
              placeholder="Last Name" 
              onChange={(e) => dispatch({ type: 'SET_LAST_NAME', payload: e.target.value })} 
            />
          </div>
          <div className="form-row">
            <input 
              type="text" 
              placeholder="Section" 
              onChange={(e) => dispatch({ type: 'SET_SECTION', payload: e.target.value })} 
            />
          </div>
          <div className="form-row">
            <input 
              type="password" 
              placeholder="Password" 
              onChange={(e) => dispatch({ type: 'SET_PASSWORD', payload: e.target.value })} 
            />
          </div>
          <div className="form-row">
            <button onClick={handleLogin}>Login</button>
          </div>
        </div>
      ) : (
        <h2>Welcome, {debouncedName} from {state.section}!</h2>
      )}

      <div>
        <h3>Simple Calculator</h3>
        <input 
          type="number" 
          placeholder="Number 1" 
          onChange={(e) => dispatch({ type: 'SET_NUMBER1', payload: e.target.value })} 
        />
        <input 
          type="number" 
          placeholder="Number 2" 
          onChange={(e) => dispatch({ type: 'SET_NUMBER2', payload: e.target.value })} 
        />
      </div>

      <div style={{ margin: '10px 0' }}>
        {['+', '-', '*', '/'].map((op) => (
          <button key={op} onClick={() => handleOperation(op)}>
            {op === '+' ? 'Addition' : op === '-' ? 'Subtraction' : op === '*' ? 'Multiplication' : 'Division'}
          </button>
        ))}
      </div>

      <button onClick={calculateResult}>=</button>
      {state.operation && state.number1 && state.number2 && (
        <p>
          {state.number1} {state.operation} {state.number2} = {state.result}
        </p>
      )}
    </div>
  );
};

export default App;
