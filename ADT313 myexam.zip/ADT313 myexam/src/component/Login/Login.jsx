import React, { useState } from 'react';

const App = () => {
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [loggedIn, setLoggedIn] = useState(false);
  const [operation, setOperation] = useState('');

  const handleLogin = () => {
    if (name && password) {
      setLoggedIn(true);
    }
  };

  const handleOperation = (op) => {
    setOperation(op);
  };

  return (
    <div>
      {!loggedIn ? (
        <div>
          <input 
            type="text" 
            placeholder="Name" 
            onChange={(e) => setName(e.target.value)} 
          />
          <input 
            type="password" 
            placeholder="Password" 
            onChange={(e) => setPassword(e.target.value)} 
          />
          <button onClick={handleLogin}>Login</button>
        </div>
      ) : (
        <h2>Welcome, {name}!</h2>
      )}

      <div>
        <h3>Simple Calculator</h3>
        {['+', '-', '*', '/'].map((op) => (
          <button key={op} onClick={() => handleOperation(op)}>
            {op === '+' ? 'Addition' : op === '-' ? 'Subtraction' : op === '*' ? 'Multiplication' : 'Division'}
          </button>
        ))}
        {operation && <p>You chose: {operation}</p>}
      </div>
    </div>
  );
};

export default App;
